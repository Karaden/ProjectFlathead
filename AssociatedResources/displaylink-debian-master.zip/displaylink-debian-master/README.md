# displaylink-debian

DisplayLink driver installer for Debian GNU/Linux, Ubuntu, Elementary OS,
Mint, and Kali Linux.


#### Problem

[DisplayLink][] releases its drivers only for Ubuntu 14.04 LTS and 16.04 LTS,
supported Linux kernel versions are 3.19 and 4.4.


#### Solution

[displaylink-debian][] allows seamless install/uninstall of the official
DisplayLink drivers on Debian GNU/Linux, Ubuntu, elementary OS, and more!

How?  Just run the script! (as root)

```sh
sudo ./displaylink-debian.sh
```


#### Technical

* _displaylink-debian.sh_ downloads and extracts the contents of the
  official [DisplayLink Ubuntu driver][upstream].

* _displaylink-debian.sh_ modifies the contents of the official installer,
  _displaylink-installer.sh_, to suit Debian and other Linux distributions.

*  Install/Uninstall is performed.

* Supported platforms are:

  * Debian: Jessie 8.0/Stretch 9.0/Sid (unstable)
  * Ubuntu: 14.04 Trusty/15.04 Vivid/15.10 Wily/16.04 Xenial/16.10 Yakkety/17.04 Zesty
  * elementary OS: O.3 Freya/0.4 Loki
  * Mint: 15 Olivia/16 Petra/17.3 Rosa/18 Sarah
  * Kali: 2016.2/kali-rolling

  Regardless of the kernel version you're using.


#### Post installation Guide and Troubleshooting

Please refer to the [Post Installation Guide][PostInstall] for further
reference.

Before submitting a bug report in the issue tracker, please make sure to
read: [Troubleshooting most common issues][TroubleShooting].


#### Discussion

* [Kernel agnostic, DisplayLink Debian GNU/Linux driver installer][blog]


[DisplayLink]:        http://www.displaylink.com/
[upstream]:           http://www.displaylink.com/downloads/ubuntu.php
[blog]:               http://foolcontrol.org/?p=1777
[displaylink-debian]: https://github.com/AdnanHodzic/displaylink-debian
[PostInstall]:        https://github.com/AdnanHodzic/displaylink-debian/blob/master/post-install-guide.md
[TroubleShooting]:    https://github.com/AdnanHodzic/displaylink-debian/blob/master/post-install-guide.md#troubleshooting-most-common-issues
